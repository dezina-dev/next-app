// pages/api/messages/index.ts
import { NextApiRequest, NextApiResponse } from 'next';
import { connectToDatabase, Message } from '../../../utils/db';
import { ObjectId } from 'mongodb';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).end(); // Method Not Allowed
  }
console.log('3333333333333333333333333333333333333333')
  const receiverId = req.query.receiverId as string;
  const userId = req.query.userId as string;

  try {
    const db = await connectToDatabase();
    const messages = db.collection<Message>('messages');
    const userMessages = await messages.find({ receiverId: new ObjectId(receiverId), userId: new ObjectId(userId) }).toArray();
    console.log('userMessages', userMessages);
    res.status(200).json(userMessages);
  } catch (error) {
    console.error('Error fetching messages:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}
