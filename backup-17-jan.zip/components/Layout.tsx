// components/Layout.tsx
import React, { ReactNode } from "react";
import Link from "next/link";
import Head from "next/head";
import router from "next/router";

type Props = {
  children?: ReactNode;
  title?: string;
};

const Layout = ({ children, title = "This is the default title" }: Props) => {
  //const user = JSON.parse(localStorage.getItem('user'));
     // Check if localStorage is available (client-side)
  //    const user = typeof window !== 'undefined' ? JSON.parse(localStorage.getItem('user')) : null;

  // const handleLogout = () => {
  //   // Perform logout logic, such as clearing localStorage
  //   localStorage.removeItem('user');
  //   // Redirect to the home page or login page
  //   router.push('/');
  // };

  return (
    <div className="flex flex-col min-h-screen">
      <Head>
        <title>{title}</title>
        <meta charSet="utf-8" />
        <meta name="viewport" content="initial-scale=1.0, width=device-width" />
      </Head>
      <header className="bg-gray-800 p-4 text-white">
        <nav className="flex items-center">
          <Link href="/" className="text-white hover:text-gray-300 mr-4">Home</Link>
          <Link href="/about" className="text-white hover:text-gray-300 mr-4">About</Link>
          <Link href="/users" className="text-white hover:text-gray-300 mr-4">Users List</Link>
          <Link href="/signup" className="text-white hover:text-gray-300 mr-4">Signup</Link>
          <Link href="/chat" className="text-white hover:text-gray-300 mr-4">Chat</Link>

          {/* Conditionally render Signup & Logout based on user login */}
          {/* {!user && <Link href="/signup" className="text-white hover:text-gray-300 mr-4">Signup</Link>}

          {user && (
           <>
            <Link href="/chat" className="text-white hover:text-gray-300 mr-4">Chat</Link>
            <button onClick={handleLogout} className="text-white hover:text-gray-300 cursor-pointer">
              Logout
            </button>
           </>
          )} */}

          <a href="/api/users" className="text-white hover:text-gray-300 ml-auto">
            Users API
          </a>
        </nav>
      </header>
      <main className="flex-1 p-4">{children}</main>
      <footer className="bg-gray-800 p-4 text-white">
        <hr className="border-gray-600" />
        <span></span>
      </footer>
    </div>
  );
};

export default Layout;
